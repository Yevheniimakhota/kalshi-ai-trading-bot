"""Exchange-authoritative Demo position inventory synchronization.

No orders. Unknown cost basis remains unmanaged. Never infer fills or P&L.
"""
import asyncio
import os
import sqlite3
from contextlib import closing
from pathlib import Path
from decimal import Decimal
from datetime import datetime, timezone

import aiosqlite

from src.jobs.reconcile_demo import fetch_all, parse_market_position
from src.jobs.order_audit import audit_resting_orders, save_audit
from src.jobs.fills_audit import fetch_all_fills, build_fills_report, save_fills_audit
from src.jobs.replay_audit import replay_fills, save_replay_report
from src.jobs.cost_basis_audit import audit_cost_basis, save_cost_basis_report
from src.jobs.fee_completeness_audit import audit_fees_and_completeness, save_fee_completeness_report
from src.jobs.order_reservation_audit import audit_order_reservations, save_order_reservation_report
from src.jobs.exit_preflight_audit import run_demo_exit_preflight, save_exit_preflight_report


async def sync_demo_positions(db_manager, client):
    """Atomically update the local inventory after a complete Demo API snapshot.

    Returns counts. Raises on API, format, or database errors; never partially
    writes when an exchange snapshot is incomplete or ambiguous.
    """
    if os.getenv('KALSHI_ENV', '').lower() != 'demo':
        raise RuntimeError('Automatic position synchronization requires Demo environment')
    if 'demo-api.kalshi.co' not in str(client.base_url).lower():
        raise RuntimeError('Refusing synchronization outside Kalshi Demo API')

    raw_positions = await fetch_all(client, '/trade-api/v2/portfolio/positions', 'market_positions')
    # Require a complete resting-order snapshot as well: don't claim we know the
    # account state if one of the essential API reads failed.
    resting = await fetch_all(client, '/trade-api/v2/portfolio/orders', 'orders', {'status': 'resting'})
    inventory = {}
    for row in raw_positions:
        ticker, side, count = parse_market_position(row)
        if not count:
            continue
        key = (ticker, side)
        if key in inventory:
            raise ValueError(f'Duplicate exchange position: {ticker} {side}')
        inventory[key] = count

    # Full matching is required before promoting a submitted local intent into
    # a real position. If fills cannot be fetched, existing live inventory still
    # syncs, but any pending/local collision fails closed.
    try:
        exchange_fills = await fetch_all_fills(client)
    except Exception:
        exchange_fills = None

    def verified_pending(pid, ticker, side, exchange_qty):
        """Require a durable ACK and exact BUY fills for THIS bot order."""
        if exchange_fills is None:
            raise RuntimeError('Cannot promote pending Demo order: fills unavailable')
        journal_path = Path(db_manager.db_path).with_name('demo_submission_intents.sqlite3')
        if not journal_path.is_file():
            raise RuntimeError('Cannot promote pending Demo order: submission journal absent')
        with closing(sqlite3.connect(f'file:{journal_path.as_posix()}?mode=ro', uri=True)) as journal:
            row = journal.execute(
                'SELECT order_id, state FROM submission_intents WHERE intent_key=?',
                (f'original_strategy_position_{pid}',)).fetchone()
        if not row or not row[0] or row[1] != 'ACKNOWLEDGED':
            raise RuntimeError('Cannot promote pending Demo order: no acknowledged exchange order')
        order_id = row[0]
        matched = [f for f in exchange_fills if str(f.get('order_id')) == order_id
                   and str(f.get('ticker')) == ticker
                   and str(f.get('side','')).upper() == side
                   and str(f.get('action','')).lower() == 'buy']
        if not matched:
            raise RuntimeError('Cannot promote pending Demo order: no matching BUY fills')
        qty = Decimal('0'); cost = Decimal('0'); seen = set()
        for fill in matched:
            fid = fill.get('fill_id')
            if not fid or fid in seen:
                raise RuntimeError('Duplicate or missing BUY fill_id')
            seen.add(fid)
            n = Decimal(str(fill['count_fp']))
            px = Decimal(str(fill[f'{side.lower()}_price_dollars']))
            if not n.is_finite() or n <= 0 or not px.is_finite() or not Decimal('0') < px < Decimal('1'):
                raise RuntimeError('Invalid BUY fill quantity or price')
            qty += n; cost += n*px
        if qty != exchange_qty:
            # Other manual buys/sells or out-of-order snapshots might exist.
            # Do not attribute those to the strategy without a complete replay.
            raise RuntimeError(f'Pending fill qty {qty} differs from exchange inventory {exchange_qty}; manual reconciliation')
        return float(cost/qty)

    # Position inventory alone does not establish entry price, ownership, or
    # strategy. Mark ALL synchronized positions unmanaged until verified fills
    # and an explicit exit-management policy are implemented.
    # SQLite's INTEGER affinity can store a REAL value without schema migration.
    # Store fractional quantities as float for this *inventory-only* snapshot;
    # do not use the database float for sizing orders or P&L calculations.
    def storage_quantity(q):
        if not isinstance(q, Decimal) or not q.is_finite() or q < 0:
            raise ValueError(f'Invalid exchange quantity: {q!r}')
        return int(q) if q == q.to_integral_value() else float(q)

    now = datetime.now(timezone.utc).isoformat()
    added = updated = closed = 0
    async with aiosqlite.connect(db_manager.db_path) as db:
        await db.execute('BEGIN IMMEDIATE')
        try:
            cursor = await db.execute('SELECT id, market_id, side, quantity, status, live FROM positions WHERE live=1')
            local = await cursor.fetchall()
            # Unique(market_id, side) is required by the existing schema.
            for pid, ticker, side, qty, status, live in local:
                key = (ticker, str(side).upper())
                exchange_qty = inventory.pop(key, Decimal(0))
                if exchange_qty:
                    # Never preserve legacy exit triggers on unverified inventory.
                    await db.execute('''UPDATE positions SET quantity=?, status='open',
                        stop_loss_price=NULL, take_profit_price=NULL,
                        max_hold_hours=NULL, target_confidence_change=NULL
                        WHERE id=?''', (storage_quantity(exchange_qty), pid))
                    updated += 1
                else:
                    await db.execute('''UPDATE positions SET status='closed',
                        strategy='exchange_unmanaged', stop_loss_price=NULL,
                        take_profit_price=NULL, max_hold_hours=NULL,
                        target_confidence_change=NULL WHERE id=?''', (pid,))
                    closed += 1
            for (ticker, side), qty in inventory.items():
                # UNIQUE(market_id, side) may be owned by a paper row.
                # Refuse to silently convert or destroy that historical row.
                cursor = await db.execute(
                    'SELECT id, live FROM positions WHERE market_id=? AND UPPER(side)=?',
                    (ticker, side))
                existing = await cursor.fetchone()
                if existing:
                    if not existing[1]:
                        cursor = await db.execute('SELECT status FROM positions WHERE id=?', (existing[0],))
                        row_status = (await cursor.fetchone())[0]
                        if row_status != 'pending':
                            raise RuntimeError(
                                f'Paper/live key collision for {ticker} {side}; '
                                'existing row is not a pending Demo intent; transaction rolled back')
                        verified_entry = verified_pending(existing[0], ticker, side, qty)
                        # Carry forward strategy metadata, but do not enable old
                        # automatic exits until cost basis / reservation checks are ready.
                        await db.execute("""UPDATE positions SET live=1, status='open',
                            quantity=?, entry_price=?, stop_loss_price=NULL,
                            take_profit_price=NULL, max_hold_hours=NULL,
                            target_confidence_change=NULL WHERE id=?""",
                            (storage_quantity(qty), verified_entry, existing[0]))
                        updated += 1
                        continue
                    await db.execute('''UPDATE positions SET quantity=?, status='open',
                        strategy='exchange_unmanaged', stop_loss_price=NULL,
                        take_profit_price=NULL, max_hold_hours=NULL,
                        target_confidence_change=NULL WHERE id=?''',
                        (storage_quantity(qty), existing[0]))
                    updated += 1
                else:
                    # 0.0 is an explicit UNKNOWN sentinel, never a tradable
                    # price; these rows are excluded from automatic exits.
                    await db.execute('''INSERT INTO positions
                        (market_id, side, entry_price, quantity, timestamp,
                         rationale, live, status, strategy)
                        VALUES (?, ?, 0.0, ?, ?, ?, 1, 'open', 'exchange_unmanaged')''',
                        (ticker, side, storage_quantity(qty), now, 'Imported from Demo API; cost basis unknown'))
                    added += 1
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    # Report only; an audit failure must not undo an already committed inventory sync.
    snapshot_inventory = {}
    for row in raw_positions:
        ticker, side, qty = parse_market_position(row)
        if qty:
            snapshot_inventory[(ticker, side)] = qty
    reservation_status = 'ok'
    try:
        reservation_report = audit_order_reservations(resting, snapshot_inventory)
        save_order_reservation_report(reservation_report, db_manager.db_path)
    except Exception as exc:
        reservation_status = f'failed: {type(exc).__name__}: {str(exc)[:160]}'

    audit_status = 'ok'
    try:
        report = audit_resting_orders(resting, snapshot_inventory)
        save_audit(report, db_manager.db_path)
    except Exception as exc:
        audit_status = f'failed: {type(exc).__name__}'

    fills_status = 'ok'
    replay_status = 'not_run'
    cost_basis_status = 'not_run'
    fee_audit_status = 'not_run'
    try:
        raw_fills = exchange_fills if exchange_fills is not None else await fetch_all_fills(client)
        fills_report = build_fills_report(raw_fills, snapshot_inventory, resting)
        save_fills_audit(fills_report, db_manager.db_path)
        try:
            replay_report = replay_fills(raw_fills, snapshot_inventory)
            save_replay_report(replay_report, db_manager.db_path)
            replay_status = 'ok'
            try:
                cost_report = audit_cost_basis(raw_fills, snapshot_inventory)
                save_cost_basis_report(cost_report, db_manager.db_path)
                cost_basis_status = 'ok'
                try:
                    fee_report = audit_fees_and_completeness(raw_fills, snapshot_inventory, resting, cost_report)
                    save_fee_completeness_report(fee_report, db_manager.db_path)
                    fee_audit_status = 'ok'
                except Exception as exc:
                    fee_audit_status = f'failed: {type(exc).__name__}: {str(exc)[:160]}' 
            except Exception as exc:
                cost_basis_status = f'failed: {type(exc).__name__}: {str(exc)[:160]}'
        except Exception as exc:
            replay_status = f'failed: {type(exc).__name__}: {str(exc)[:160]}'
    except Exception as exc:
        fills_status = f'failed: {type(exc).__name__}: {str(exc)[:160]}'

    preflight_status = 'ok'
    try:
        preflight_report = await run_demo_exit_preflight(client)
        save_exit_preflight_report(preflight_report, db_manager.db_path)
    except Exception as exc:
        preflight_status = f'failed: {type(exc).__name__}: {str(exc)[:160]}'

    return {'added': added, 'updated': updated, 'closed': closed,
            'exchange_positions': len(raw_positions), 'resting_orders': len(resting),
            'order_audit': audit_status, 'fills_audit': fills_status,
            'replay_audit': replay_status, 'cost_basis_audit': cost_basis_status,
            'fee_completeness_audit': fee_audit_status,
            'order_reservation_audit': reservation_status,
            'exit_preflight_audit': preflight_status}
